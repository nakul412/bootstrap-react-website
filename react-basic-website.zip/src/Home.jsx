import React from 'react';
import ReactDOM from 'react-dom';
import {NavLink} from 'react-router-dom';
import Common from './Common';
const Home=()=>{
return(
    <>
    
<Common 
heading="Grow your business with " button="Get Started"
visit="/service"/>
    </>
)
}
export default Home;